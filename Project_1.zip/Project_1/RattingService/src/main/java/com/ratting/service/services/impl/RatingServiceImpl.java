package com.ratting.service.services.impl;

import com.ratting.service.entities.Rating;
import com.ratting.service.respositories.RatingRepository;
import com.ratting.service.services.RatingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class RatingServiceImpl implements RatingService {

    @Autowired
    private RatingRepository ratingRepository;

    @Override
    public Rating create(Rating rating) {
        rating.setRattingId(UUID.randomUUID().toString());
        return this.ratingRepository.save(rating);
    }

    @Override
    public Rating getRating(String ratingId) {
        return this.ratingRepository.findById(ratingId).orElse(null);
    }

    @Override
    public List<Rating> getAllRatings() {
        return this.ratingRepository.findAll();
    }

    @Override
    public List<Rating> getRatingsByUserId(String userId) {
        return this.ratingRepository.findByUserId(userId);
    }

    @Override
    public List<Rating> getRatingsByHotelId(String hotelId) {
        return this.ratingRepository.findByHotelId(hotelId);
    }
}
