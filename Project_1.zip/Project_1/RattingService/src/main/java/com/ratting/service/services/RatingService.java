package com.ratting.service.services;

import com.ratting.service.entities.Rating;
import org.springframework.stereotype.Service;
import java.util.List;

public interface RatingService {
    Rating create(Rating rating);
    Rating getRating(String ratingId);
    List<Rating> getAllRatings();
    List<Rating> getRatingsByUserId(String userId);
    List<Rating> getRatingsByHotelId(String hotelId);
}
