package com.ratting.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RattingServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(RattingServiceApplication.class, args);
    }

}
