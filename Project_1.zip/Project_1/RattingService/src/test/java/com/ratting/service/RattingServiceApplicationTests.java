package com.ratting.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RattingServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
