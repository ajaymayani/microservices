package com.user.service.entities;

import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "users")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class User {
    @Id
    @Column(name = "id")
    private String userId;
    private String name;
    private String email;
    @Transient
    private List<Rating> ratings = new ArrayList<Rating>();
}
