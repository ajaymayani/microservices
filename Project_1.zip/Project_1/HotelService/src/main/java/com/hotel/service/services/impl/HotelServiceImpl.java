package com.hotel.service.services.impl;

import com.hotel.service.etities.Hotel;
import com.hotel.service.exceptions.ResourceNotFoundException;
import com.hotel.service.repositories.HotelRepository;
import com.hotel.service.services.HotelService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class HotelServiceImpl implements HotelService {
    @Autowired
    private HotelRepository hotelRepository;
    private final static Logger log = LoggerFactory.getLogger(HotelServiceImpl.class);

    @Override
    public Hotel create(Hotel hotel) {
        log.info("Hotel created {}",hotel);
        String id = UUID.randomUUID().toString();
        hotel.setId(id);
        return this.hotelRepository.save(hotel);
    }

    @Override
    public List<Hotel> getALlHotels() {
        log.info("Hotel getALlHotels");
        return this.hotelRepository.findAll();
    }

    @Override
    public Hotel getHotelById(String id) {
        log.info("Hotel getHotelById {}",id);
        return this.hotelRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("Hotel with given id not found"));
    }
}
