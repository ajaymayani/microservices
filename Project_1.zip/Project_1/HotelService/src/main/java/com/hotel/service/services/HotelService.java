package com.hotel.service.services;

import com.hotel.service.etities.Hotel;

import java.util.List;

public interface HotelService {

    Hotel create(Hotel hotel);

    List<Hotel> getALlHotels();

    Hotel getHotelById(String id);
}
