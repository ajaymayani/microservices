package com.hotel.service.controller;

import com.hotel.service.etities.Hotel;
import com.hotel.service.services.HotelService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;


@RestController
@RequestMapping("/hotels")
public class HotelController {
    @Autowired
    private HotelService hotelService;
    private final static Logger log = LoggerFactory.getLogger(HotelController.class);

    @PostMapping
    public ResponseEntity<Hotel> createHotel(@RequestBody Hotel hotel) {
        log.info("REST Hotel created");
        return ResponseEntity.status(HttpStatus.CREATED).body(this.hotelService.create(hotel));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Hotel> getHotelById(@PathVariable("id") String id) {
        log.info("REST Get Hotel by id {}",id);
        return ResponseEntity.ok(this.hotelService.getHotelById(id));
    }

    @GetMapping
    public ResponseEntity<List<Hotel>> getAllHotels() {
        log.info("REST Get All Hotels");
        return ResponseEntity.ok(this.hotelService.getALlHotels());
    }
}
